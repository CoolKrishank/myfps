# First Person Shooter with JS

### A simple FPS game made in JavaScript using THREE.js, Physijs... with the purpose of learning a little bit of these libraries

## How to use it in Windows

- Open cmd and access the game directory.
- Python 3.5 or above must be installed (or a tool that provides you with a local web server).
- Use the command `python -m http.server 8000` in cmd.
- Open a web browser and type [localhost:8000/](http://localhost:8000/).
- When you are in [localhost:8000/](http://localhost:8000/), search the game's folder (/fps).
